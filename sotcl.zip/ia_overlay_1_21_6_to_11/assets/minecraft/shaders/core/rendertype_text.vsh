#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_48355867(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_4d9f1fde() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_21120594(inout vec4 vertex) {
    f_48355867(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_4d9f1fde();
    }
    finalize();
}



void f_157f2b56() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_b5ba4ce5() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_4739c49d(inout vec4 vertex) {
    f_48355867(vertex);
    f_157f2b56();
    finalize();
}

void f_bf0f1ee2(inout vec4 vertex) {
    f_48355867(vertex);
    f_4d9f1fde();
    f_b5ba4ce5();
    finalize();
}

void f_0a39a6f7(inout vec4 vertex) {
    f_48355867(vertex);
    f_b5ba4ce5();
    f_157f2b56();
    finalize();
}

void f_1ed6dabf(inout vec4 vertex) {
    f_4d9f1fde();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_48355867(vertex);
    finalize();
}

void f_edee32fb(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_157f2b56();
    f_48355867(vertex);
    finalize();
}

void f_56a336f3(inout vec4 vertex, float speed) {
    f_48355867(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_285f9330(inout vec4 vertex) {
    f_48355867(vertex);
    f_4d9f1fde();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_21120594(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_4d9f1fde();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_48355867(vertex);
            f_4d9f1fde();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_bf0f1ee2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_bf0f1ee2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_1ed6dabf(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_1ed6dabf(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_56a336f3(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_285f9330(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_4739c49d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_bf0f1ee2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_0a39a6f7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_1ed6dabf(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_edee32fb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_56a336f3(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_4739c49d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_bf0f1ee2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_0a39a6f7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_1ed6dabf(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_edee32fb(vertex);
        return;
    }
    

    
    f_48355867(vertex);
    f_4d9f1fde();
    finalize();
}