#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_d88d665b(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_faacfc35() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_1ea99a6f(inout vec4 vertex) {
    f_d88d665b(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_faacfc35();
    }
    finalize();
}



void f_3a14f6cb() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_834199ea() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_b6361493(inout vec4 vertex) {
    f_d88d665b(vertex);
    f_3a14f6cb();
    finalize();
}

void f_974e89b0(inout vec4 vertex) {
    f_d88d665b(vertex);
    f_faacfc35();
    f_834199ea();
    finalize();
}

void f_542910c3(inout vec4 vertex) {
    f_d88d665b(vertex);
    f_834199ea();
    f_3a14f6cb();
    finalize();
}

void f_cf22e405(inout vec4 vertex) {
    f_faacfc35();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_d88d665b(vertex);
    finalize();
}

void f_c7e65959(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_3a14f6cb();
    f_d88d665b(vertex);
    finalize();
}

void f_ff897080(inout vec4 vertex, float speed) {
    f_d88d665b(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_ada458eb(inout vec4 vertex) {
    f_d88d665b(vertex);
    f_faacfc35();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_1ea99a6f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_faacfc35();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_d88d665b(vertex);
            f_faacfc35();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_974e89b0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_974e89b0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_cf22e405(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_cf22e405(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_ff897080(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_ada458eb(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_b6361493(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_974e89b0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_542910c3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_cf22e405(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c7e65959(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_ff897080(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_b6361493(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_974e89b0(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_542910c3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_cf22e405(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c7e65959(vertex);
        return;
    }
    

    
    f_d88d665b(vertex);
    f_faacfc35();
    finalize();
}