#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_fc157c33(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_e851855e() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_04e82bc6(inout vec4 vertex) {
    f_fc157c33(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_e851855e();
    }
    finalize();
}



void f_33d33f5b() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_78b6a6e6() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_32ce9160(inout vec4 vertex) {
    f_fc157c33(vertex);
    f_33d33f5b();
    finalize();
}

void f_cb150b03(inout vec4 vertex) {
    f_fc157c33(vertex);
    f_e851855e();
    f_78b6a6e6();
    finalize();
}

void f_84d4cfaa(inout vec4 vertex) {
    f_fc157c33(vertex);
    f_78b6a6e6();
    f_33d33f5b();
    finalize();
}

void f_fa062cef(inout vec4 vertex) {
    f_e851855e();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_fc157c33(vertex);
    finalize();
}

void f_2bbf8bc1(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_33d33f5b();
    f_fc157c33(vertex);
    finalize();
}

void f_f579dd2a(inout vec4 vertex, float speed) {
    f_fc157c33(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_69d29647(inout vec4 vertex) {
    f_fc157c33(vertex);
    f_e851855e();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_04e82bc6(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_e851855e();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_fc157c33(vertex);
            f_e851855e();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_cb150b03(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_cb150b03(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_fa062cef(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_fa062cef(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_f579dd2a(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_69d29647(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_32ce9160(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_cb150b03(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_84d4cfaa(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_fa062cef(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_2bbf8bc1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_f579dd2a(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_32ce9160(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_cb150b03(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_84d4cfaa(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_fa062cef(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_2bbf8bc1(vertex);
        return;
    }
    

    
    f_fc157c33(vertex);
    f_e851855e();
    finalize();
}