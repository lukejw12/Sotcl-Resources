#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_80c68516(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_5499ee7d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_ab3b998c(inout vec4 vertex) {
    f_80c68516(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_5499ee7d();
    }
    finalize();
}



void f_d1aad793() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_819813b2() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_89c70c1e(inout vec4 vertex) {
    f_80c68516(vertex);
    f_d1aad793();
    finalize();
}

void f_95b09294(inout vec4 vertex) {
    f_80c68516(vertex);
    f_5499ee7d();
    f_819813b2();
    finalize();
}

void f_0306c738(inout vec4 vertex) {
    f_80c68516(vertex);
    f_819813b2();
    f_d1aad793();
    finalize();
}

void f_0b66dfd7(inout vec4 vertex) {
    f_5499ee7d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_80c68516(vertex);
    finalize();
}

void f_04198bd4(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_d1aad793();
    f_80c68516(vertex);
    finalize();
}

void f_4bf963d5(inout vec4 vertex, float speed) {
    f_80c68516(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_9c280f93(inout vec4 vertex) {
    f_80c68516(vertex);
    f_5499ee7d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_ab3b998c(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_5499ee7d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_80c68516(vertex);
            f_5499ee7d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_95b09294(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_95b09294(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_0b66dfd7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_0b66dfd7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_4bf963d5(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_9c280f93(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_89c70c1e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_95b09294(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_0306c738(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_0b66dfd7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_04198bd4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_4bf963d5(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_89c70c1e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_95b09294(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_0306c738(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_0b66dfd7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_04198bd4(vertex);
        return;
    }
    

    
    f_80c68516(vertex);
    f_5499ee7d();
    finalize();
}