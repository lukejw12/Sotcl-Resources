#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_64a0efec(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_8682caa5() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_5a1a28c2(inout vec4 vertex) {
    f_64a0efec(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_8682caa5();
    }
    finalize();
}



void f_7d98b23e() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_9cab2ba5() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_05bb6d21(inout vec4 vertex) {
    f_64a0efec(vertex);
    f_7d98b23e();
    finalize();
}

void f_54c05663(inout vec4 vertex) {
    f_64a0efec(vertex);
    f_8682caa5();
    f_9cab2ba5();
    finalize();
}

void f_f620c343(inout vec4 vertex) {
    f_64a0efec(vertex);
    f_9cab2ba5();
    f_7d98b23e();
    finalize();
}

void f_6729cbc9(inout vec4 vertex) {
    f_8682caa5();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_64a0efec(vertex);
    finalize();
}

void f_605fb57d(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7d98b23e();
    f_64a0efec(vertex);
    finalize();
}

void f_c97992c1(inout vec4 vertex, float speed) {
    f_64a0efec(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_e3ed4670(inout vec4 vertex) {
    f_64a0efec(vertex);
    f_8682caa5();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_5a1a28c2(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_8682caa5();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_64a0efec(vertex);
            f_8682caa5();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_54c05663(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_54c05663(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_6729cbc9(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_6729cbc9(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c97992c1(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_e3ed4670(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_05bb6d21(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_54c05663(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_f620c343(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_6729cbc9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_605fb57d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c97992c1(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_05bb6d21(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_54c05663(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_f620c343(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_6729cbc9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_605fb57d(vertex);
        return;
    }
    

    
    f_64a0efec(vertex);
    f_8682caa5();
    finalize();
}