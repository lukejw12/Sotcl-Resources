#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_c177c452(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_f017c083() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_9f96b53f(inout vec4 vertex) {
    f_c177c452(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_f017c083();
    }
    finalize();
}



void f_f63067b2() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_d3eff3b2() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_2eb24ea3(inout vec4 vertex) {
    f_c177c452(vertex);
    f_f63067b2();
    finalize();
}

void f_92b5c621(inout vec4 vertex) {
    f_c177c452(vertex);
    f_f017c083();
    f_d3eff3b2();
    finalize();
}

void f_179ae20f(inout vec4 vertex) {
    f_c177c452(vertex);
    f_d3eff3b2();
    f_f63067b2();
    finalize();
}

void f_3fb91b35(inout vec4 vertex) {
    f_f017c083();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_c177c452(vertex);
    finalize();
}

void f_54386702(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_f63067b2();
    f_c177c452(vertex);
    finalize();
}

void f_b0386d8a(inout vec4 vertex, float speed) {
    f_c177c452(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_d638bb6b(inout vec4 vertex) {
    f_c177c452(vertex);
    f_f017c083();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_9f96b53f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_f017c083();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_c177c452(vertex);
            f_f017c083();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_92b5c621(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_92b5c621(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_3fb91b35(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_3fb91b35(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_b0386d8a(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_d638bb6b(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_2eb24ea3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_92b5c621(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_179ae20f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_3fb91b35(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_54386702(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_b0386d8a(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_2eb24ea3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_92b5c621(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_179ae20f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_3fb91b35(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_54386702(vertex);
        return;
    }
    

    
    f_c177c452(vertex);
    f_f017c083();
    finalize();
}