#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_74620b3d(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_20950be5() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_3db06ab2(inout vec4 vertex) {
    f_74620b3d(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_20950be5();
    }
    finalize();
}



void f_1bfe2612() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_e7ccb8e9() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_0024e55e(inout vec4 vertex) {
    f_74620b3d(vertex);
    f_1bfe2612();
    finalize();
}

void f_715c4f9a(inout vec4 vertex) {
    f_74620b3d(vertex);
    f_20950be5();
    f_e7ccb8e9();
    finalize();
}

void f_44b57b76(inout vec4 vertex) {
    f_74620b3d(vertex);
    f_e7ccb8e9();
    f_1bfe2612();
    finalize();
}

void f_d221dcec(inout vec4 vertex) {
    f_20950be5();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_74620b3d(vertex);
    finalize();
}

void f_9070ca71(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1bfe2612();
    f_74620b3d(vertex);
    finalize();
}

void f_fb7988a1(inout vec4 vertex, float speed) {
    f_74620b3d(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_ab726eaf(inout vec4 vertex) {
    f_74620b3d(vertex);
    f_20950be5();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_3db06ab2(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_20950be5();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_74620b3d(vertex);
            f_20950be5();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_715c4f9a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_715c4f9a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_d221dcec(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_d221dcec(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_fb7988a1(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_ab726eaf(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_0024e55e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_715c4f9a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_44b57b76(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_d221dcec(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_9070ca71(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_fb7988a1(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_0024e55e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_715c4f9a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_44b57b76(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_d221dcec(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_9070ca71(vertex);
        return;
    }
    

    
    f_74620b3d(vertex);
    f_20950be5();
    finalize();
}