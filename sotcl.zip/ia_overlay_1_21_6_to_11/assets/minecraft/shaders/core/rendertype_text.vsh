#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_0a645ba9(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_06f3bd25() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_e0009d2c(inout vec4 vertex) {
    f_0a645ba9(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_06f3bd25();
    }
    finalize();
}



void f_1dafc089() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_9a840b8d() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_e27cb761(inout vec4 vertex) {
    f_0a645ba9(vertex);
    f_1dafc089();
    finalize();
}

void f_d0301d0a(inout vec4 vertex) {
    f_0a645ba9(vertex);
    f_06f3bd25();
    f_9a840b8d();
    finalize();
}

void f_d41846c5(inout vec4 vertex) {
    f_0a645ba9(vertex);
    f_9a840b8d();
    f_1dafc089();
    finalize();
}

void f_7da27cd3(inout vec4 vertex) {
    f_06f3bd25();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0a645ba9(vertex);
    finalize();
}

void f_ae7f4a98(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1dafc089();
    f_0a645ba9(vertex);
    finalize();
}

void f_58814cf9(inout vec4 vertex, float speed) {
    f_0a645ba9(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_40e5aa86(inout vec4 vertex) {
    f_0a645ba9(vertex);
    f_06f3bd25();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_e0009d2c(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_06f3bd25();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_0a645ba9(vertex);
            f_06f3bd25();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_d0301d0a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_d0301d0a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_7da27cd3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_7da27cd3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_58814cf9(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_40e5aa86(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_e27cb761(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_d0301d0a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_d41846c5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_7da27cd3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_ae7f4a98(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_58814cf9(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_e27cb761(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_d0301d0a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_d41846c5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_7da27cd3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_ae7f4a98(vertex);
        return;
    }
    

    
    f_0a645ba9(vertex);
    f_06f3bd25();
    finalize();
}