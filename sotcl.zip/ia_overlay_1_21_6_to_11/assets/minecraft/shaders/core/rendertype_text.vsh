#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_8317fa25(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_3e12e3f4() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_ef19f4a6(inout vec4 vertex) {
    f_8317fa25(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_3e12e3f4();
    }
    finalize();
}



void f_72624e2b() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_482786de() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_ed558982(inout vec4 vertex) {
    f_8317fa25(vertex);
    f_72624e2b();
    finalize();
}

void f_513b6874(inout vec4 vertex) {
    f_8317fa25(vertex);
    f_3e12e3f4();
    f_482786de();
    finalize();
}

void f_6f61b714(inout vec4 vertex) {
    f_8317fa25(vertex);
    f_482786de();
    f_72624e2b();
    finalize();
}

void f_1d864bc5(inout vec4 vertex) {
    f_3e12e3f4();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_8317fa25(vertex);
    finalize();
}

void f_ad89472b(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_72624e2b();
    f_8317fa25(vertex);
    finalize();
}

void f_d15cd85b(inout vec4 vertex, float speed) {
    f_8317fa25(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_e4604326(inout vec4 vertex) {
    f_8317fa25(vertex);
    f_3e12e3f4();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_ef19f4a6(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_3e12e3f4();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_8317fa25(vertex);
            f_3e12e3f4();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_513b6874(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_513b6874(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_1d864bc5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_1d864bc5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_d15cd85b(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_e4604326(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_ed558982(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_513b6874(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_6f61b714(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_1d864bc5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_ad89472b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_d15cd85b(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_ed558982(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_513b6874(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_6f61b714(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_1d864bc5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_ad89472b(vertex);
        return;
    }
    

    
    f_8317fa25(vertex);
    f_3e12e3f4();
    finalize();
}