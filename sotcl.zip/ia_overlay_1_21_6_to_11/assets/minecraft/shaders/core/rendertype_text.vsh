#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_392b2677(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_900723cc() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_a507137c(inout vec4 vertex) {
    f_392b2677(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_900723cc();
    }
    finalize();
}



void f_f3ad36fc() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_b79b54e5() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_eb848484(inout vec4 vertex) {
    f_392b2677(vertex);
    f_f3ad36fc();
    finalize();
}

void f_d6402752(inout vec4 vertex) {
    f_392b2677(vertex);
    f_900723cc();
    f_b79b54e5();
    finalize();
}

void f_a8afca1b(inout vec4 vertex) {
    f_392b2677(vertex);
    f_b79b54e5();
    f_f3ad36fc();
    finalize();
}

void f_1001785e(inout vec4 vertex) {
    f_900723cc();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_392b2677(vertex);
    finalize();
}

void f_a1890241(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_f3ad36fc();
    f_392b2677(vertex);
    finalize();
}

void f_d090bf9c(inout vec4 vertex, float speed) {
    f_392b2677(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_b4eed444(inout vec4 vertex) {
    f_392b2677(vertex);
    f_900723cc();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_a507137c(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_900723cc();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_392b2677(vertex);
            f_900723cc();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_d6402752(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_d6402752(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_1001785e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_1001785e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_d090bf9c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_b4eed444(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_eb848484(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_d6402752(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_a8afca1b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_1001785e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_a1890241(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_d090bf9c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_eb848484(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_d6402752(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_a8afca1b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_1001785e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_a1890241(vertex);
        return;
    }
    

    
    f_392b2677(vertex);
    f_900723cc();
    finalize();
}