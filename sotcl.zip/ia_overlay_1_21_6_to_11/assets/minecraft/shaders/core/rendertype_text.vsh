#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_9962eea0(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_1c4a5688() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_010a32d7(inout vec4 vertex) {
    f_9962eea0(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_1c4a5688();
    }
    finalize();
}



void f_1f5e5b56() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_33a29a4e() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_70e7c958(inout vec4 vertex) {
    f_9962eea0(vertex);
    f_1f5e5b56();
    finalize();
}

void f_92770752(inout vec4 vertex) {
    f_9962eea0(vertex);
    f_1c4a5688();
    f_33a29a4e();
    finalize();
}

void f_06a21fe5(inout vec4 vertex) {
    f_9962eea0(vertex);
    f_33a29a4e();
    f_1f5e5b56();
    finalize();
}

void f_ba81fe61(inout vec4 vertex) {
    f_1c4a5688();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9962eea0(vertex);
    finalize();
}

void f_fcf5c091(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1f5e5b56();
    f_9962eea0(vertex);
    finalize();
}

void f_2b28299f(inout vec4 vertex, float speed) {
    f_9962eea0(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_cc82b3fd(inout vec4 vertex) {
    f_9962eea0(vertex);
    f_1c4a5688();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_010a32d7(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_1c4a5688();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_9962eea0(vertex);
            f_1c4a5688();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_92770752(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_92770752(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_ba81fe61(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_ba81fe61(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_2b28299f(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_cc82b3fd(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_70e7c958(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_92770752(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_06a21fe5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_ba81fe61(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_fcf5c091(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_2b28299f(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_70e7c958(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_92770752(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_06a21fe5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_ba81fe61(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_fcf5c091(vertex);
        return;
    }
    

    
    f_9962eea0(vertex);
    f_1c4a5688();
    finalize();
}