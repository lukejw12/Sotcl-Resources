#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_305d27fa(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_0aa20b65() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_6982e379(inout vec4 vertex) {
    f_305d27fa(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_0aa20b65();
    }
    finalize();
}



void f_43ab770d() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_0574dfe1() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_cf71d556(inout vec4 vertex) {
    f_305d27fa(vertex);
    f_43ab770d();
    finalize();
}

void f_9de6f76e(inout vec4 vertex) {
    f_305d27fa(vertex);
    f_0aa20b65();
    f_0574dfe1();
    finalize();
}

void f_fb80079b(inout vec4 vertex) {
    f_305d27fa(vertex);
    f_0574dfe1();
    f_43ab770d();
    finalize();
}

void f_c71a1408(inout vec4 vertex) {
    f_0aa20b65();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_305d27fa(vertex);
    finalize();
}

void f_bb4859d6(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_43ab770d();
    f_305d27fa(vertex);
    finalize();
}

void f_91bbe4aa(inout vec4 vertex, float speed) {
    f_305d27fa(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_f00ce373(inout vec4 vertex) {
    f_305d27fa(vertex);
    f_0aa20b65();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_6982e379(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_0aa20b65();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_305d27fa(vertex);
            f_0aa20b65();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_9de6f76e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_9de6f76e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_c71a1408(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_c71a1408(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_91bbe4aa(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_f00ce373(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_cf71d556(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_9de6f76e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_fb80079b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_c71a1408(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_bb4859d6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_91bbe4aa(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_cf71d556(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_9de6f76e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_fb80079b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_c71a1408(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_bb4859d6(vertex);
        return;
    }
    

    
    f_305d27fa(vertex);
    f_0aa20b65();
    finalize();
}