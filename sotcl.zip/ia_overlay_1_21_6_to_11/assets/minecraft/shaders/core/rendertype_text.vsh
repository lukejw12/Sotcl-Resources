#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_f8d9bd69(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ac1a1b6b() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_7cfef125(inout vec4 vertex) {
    f_f8d9bd69(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ac1a1b6b();
    }
    finalize();
}



void f_7486874f() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_299fa435() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_a8ba9042(inout vec4 vertex) {
    f_f8d9bd69(vertex);
    f_7486874f();
    finalize();
}

void f_6f99167a(inout vec4 vertex) {
    f_f8d9bd69(vertex);
    f_ac1a1b6b();
    f_299fa435();
    finalize();
}

void f_997f61f0(inout vec4 vertex) {
    f_f8d9bd69(vertex);
    f_299fa435();
    f_7486874f();
    finalize();
}

void f_08982e8b(inout vec4 vertex) {
    f_ac1a1b6b();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_f8d9bd69(vertex);
    finalize();
}

void f_c940b631(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7486874f();
    f_f8d9bd69(vertex);
    finalize();
}

void f_cf2f3642(inout vec4 vertex, float speed) {
    f_f8d9bd69(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_fe03ea7a(inout vec4 vertex) {
    f_f8d9bd69(vertex);
    f_ac1a1b6b();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_7cfef125(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ac1a1b6b();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_f8d9bd69(vertex);
            f_ac1a1b6b();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_6f99167a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_6f99167a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_08982e8b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_08982e8b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_cf2f3642(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_fe03ea7a(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_a8ba9042(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_6f99167a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_997f61f0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_08982e8b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c940b631(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_cf2f3642(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_a8ba9042(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_6f99167a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_997f61f0(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_08982e8b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c940b631(vertex);
        return;
    }
    

    
    f_f8d9bd69(vertex);
    f_ac1a1b6b();
    finalize();
}