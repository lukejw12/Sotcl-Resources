#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_d0b36ba6(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_e891b225() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_3bb973f0(inout vec4 vertex) {
    f_d0b36ba6(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_e891b225();
    }
    finalize();
}



void f_60b122ee() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_30c1b4d9() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_4c1e73b5(inout vec4 vertex) {
    f_d0b36ba6(vertex);
    f_60b122ee();
    finalize();
}

void f_c14af2a3(inout vec4 vertex) {
    f_d0b36ba6(vertex);
    f_e891b225();
    f_30c1b4d9();
    finalize();
}

void f_7dc8b28d(inout vec4 vertex) {
    f_d0b36ba6(vertex);
    f_30c1b4d9();
    f_60b122ee();
    finalize();
}

void f_fbcdd0e2(inout vec4 vertex) {
    f_e891b225();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_d0b36ba6(vertex);
    finalize();
}

void f_bd91b57a(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_60b122ee();
    f_d0b36ba6(vertex);
    finalize();
}

void f_02939761(inout vec4 vertex, float speed) {
    f_d0b36ba6(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_a1057ca6(inout vec4 vertex) {
    f_d0b36ba6(vertex);
    f_e891b225();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_3bb973f0(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_e891b225();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_d0b36ba6(vertex);
            f_e891b225();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_c14af2a3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_c14af2a3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_fbcdd0e2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_fbcdd0e2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_02939761(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_a1057ca6(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_4c1e73b5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_c14af2a3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_7dc8b28d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_fbcdd0e2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_bd91b57a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_02939761(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_4c1e73b5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_c14af2a3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_7dc8b28d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_fbcdd0e2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_bd91b57a(vertex);
        return;
    }
    

    
    f_d0b36ba6(vertex);
    f_e891b225();
    finalize();
}