#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_e832f4ac(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_44c0410d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_1474ff00(inout vec4 vertex) {
    f_e832f4ac(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_44c0410d();
    }
    finalize();
}



void f_eade5a87() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_ff7c3146() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_6e01f826(inout vec4 vertex) {
    f_e832f4ac(vertex);
    f_eade5a87();
    finalize();
}

void f_128fb3cb(inout vec4 vertex) {
    f_e832f4ac(vertex);
    f_44c0410d();
    f_ff7c3146();
    finalize();
}

void f_88b064d1(inout vec4 vertex) {
    f_e832f4ac(vertex);
    f_ff7c3146();
    f_eade5a87();
    finalize();
}

void f_aa891309(inout vec4 vertex) {
    f_44c0410d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_e832f4ac(vertex);
    finalize();
}

void f_c3b5507f(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_eade5a87();
    f_e832f4ac(vertex);
    finalize();
}

void f_72ce698f(inout vec4 vertex, float speed) {
    f_e832f4ac(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_9b74ae07(inout vec4 vertex) {
    f_e832f4ac(vertex);
    f_44c0410d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_1474ff00(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_44c0410d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_e832f4ac(vertex);
            f_44c0410d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_128fb3cb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_128fb3cb(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_aa891309(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_aa891309(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_72ce698f(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_9b74ae07(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_6e01f826(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_128fb3cb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_88b064d1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_aa891309(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c3b5507f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_72ce698f(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_6e01f826(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_128fb3cb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_88b064d1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_aa891309(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c3b5507f(vertex);
        return;
    }
    

    
    f_e832f4ac(vertex);
    f_44c0410d();
    finalize();
}