#version 330

// Vanilla copy of position_tex_color.vsh with one addition: the End sky fix (see main()).
// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 texCoord0;
out vec4 vertexColor;

// How bright the End sky texture is drawn. Vanilla multiplies it by 0x282828 (~0.16), which is why the
// default sky looks so dim. 1.0 = the texture exactly as painted.
const float END_SKY_BRIGHTNESS = 1.0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vec2 uv = UV0;
    vec4 color = Color;

    // The End sky: six cube faces drawn with UVs 0..16 (so the texture tiles 16x16 per face) and vertex
    // colour 0x282828. Nothing else uses this shader with UVs that large AND that exact colour, so this
    // is a safe fingerprint. Map the UVs back to 0..1: one full texture per face.
    if (max(abs(uv.x), abs(uv.y)) > 1.5
            && abs(color.r - 40.0 / 255.0) < 0.01
            && abs(color.g - 40.0 / 255.0) < 0.01
            && abs(color.b - 40.0 / 255.0) < 0.01) {
        uv = uv / 16.0;
        color = vec4(vec3(END_SKY_BRIGHTNESS), color.a);
    }

    texCoord0 = uv;
    vertexColor = color;
}
