#version 330

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

const vec3 TEAM_COLORS[16] = vec3[](
    vec3(0.000, 0.000, 0.000), vec3(0.000, 0.000, 0.667), vec3(0.000, 0.667, 0.000), vec3(0.000, 0.667, 0.667),
    vec3(0.667, 0.000, 0.000), vec3(0.667, 0.000, 0.667), vec3(1.000, 0.667, 0.000), vec3(0.667, 0.667, 0.667),
    vec3(0.333, 0.333, 0.333), vec3(0.333, 0.333, 1.000), vec3(0.333, 1.000, 0.333), vec3(0.333, 1.000, 1.000),
    vec3(1.000, 0.333, 0.333), vec3(1.000, 0.333, 1.000), vec3(1.000, 1.000, 0.333), vec3(1.000, 1.000, 1.000)
);

const int MARKER_INDEX = 5;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }

    bool eye = abs(color.a - 0.9686) < 0.002;  // alpha 247, exact match

    vec3 c = ColorModulator.rgb * vertexColor.rgb;
    int best = 15;
    float bestDist = 1e9;
    for (int i = 0; i < 16; i++) {
        float d = distance(c, TEAM_COLORS[i]);
        if (d < bestDist) {
            bestDist = d;
            best = i;
        }
    }


    if (best == MARKER_INDEX) {

        if (!gl_FrontFacing) {
            discard;
        }
        if (eye) {

            if (((int(gl_FragCoord.x) + int(gl_FragCoord.y)) & 1) == 1) {
                discard;
            }
        } else {
            vec3 seed = vec3(fract(texCoord0 * 251.0) * 2.0 - 1.0,
                             fract((gl_FragCoord.x + gl_FragCoord.y * 61.0) * 0.0173));
            float h = fract(sin(dot(seed, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
            if (h > 0.5) {
                discard;
            }
        }
    }

    float z = gl_FragCoord.z;
    float zHi = floor(z * 255.0) / 255.0;
    float zLo = clamp(fract(z * 255.0), 0.0, 1.0);
    fragColor = vec4((float(best) + (eye ? 16.0 : 0.0)) / 31.0, zHi, zLo, 1.0);
}
