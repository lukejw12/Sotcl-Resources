#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sotcl_nv.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in float nvFactor;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    float envStart = FogEnvironmentalStart;
    float envEnd = FogEnvironmentalEnd;
    sotcl_nv_fog_bounds(nvFactor, envStart, envEnd);
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, envStart, envEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
