#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 s = texture(InSampler, texCoord);
    if (s.a < 0.5) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    float z = s.g + s.b / 255.0;
    float dist = 0.05 / max(1.0 - z, 0.00002);
    float enc = clamp(dist / 32.0, 0.0, 1.0);
    fragColor = vec4(enc, 1.0, 0.0, 1.0);
}
