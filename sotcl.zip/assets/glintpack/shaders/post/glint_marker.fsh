#version 330

#moj_import <minecraft:globals.glsl>

uniform sampler2D OutlineSampler;
uniform sampler2D MainDepthSampler;
uniform sampler2D DistSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 OutlineSize;
    vec2 MainDepthSize;
    vec2 DistSize;
};

layout(std140) uniform GlintConfig {
    vec4 MarkerColor;
    vec4 GlintColor;
    vec4 GlintParams;
    vec4 BaseColor;
};

in vec2 texCoord;
out vec4 fragColor;

const float TAU = 6.2831853;

const vec3 TEAM_COLORS[16] = vec3[](
    vec3(0.000, 0.000, 0.000), vec3(0.000, 0.000, 0.667), vec3(0.000, 0.667, 0.000), vec3(0.000, 0.667, 0.667),
    vec3(0.667, 0.000, 0.000), vec3(0.667, 0.000, 0.667), vec3(1.000, 0.667, 0.000), vec3(0.667, 0.667, 0.667),
    vec3(0.333, 0.333, 0.333), vec3(0.333, 0.333, 1.000), vec3(0.333, 1.000, 0.333), vec3(0.333, 1.000, 1.000),
    vec3(1.000, 0.333, 0.333), vec3(1.000, 0.333, 1.000), vec3(1.000, 1.000, 0.333), vec3(1.000, 1.000, 1.000)
);

float linearize(float z) {
    return 0.05 / max(1.0 - z, 0.00002);
}


float shimmer(vec2 p) {
    float t1 = TAU * GameTime * GlintParams.y;
    float t2 = TAU * GameTime * GlintParams.z;
    float d1 = dot(p, normalize(vec2(1.0, 0.55)));
    float d2 = dot(p, normalize(vec2(1.0, -0.35)));
    float s1 = pow(0.5 + 0.5 * sin(d1 * TAU + t1), 3.0);
    float s2 = pow(0.5 + 0.5 * sin(d1 * 2.7 * TAU + t2 + 1.9), 5.0) * 0.55;
    float sway = 0.65 + 0.35 * sin(d2 * 0.6 * TAU + t2);
    return clamp((s1 + s2) * sway, 0.0, 1.0);
}

void main() {
    vec2 oneTexel = 1.0 / OutlineSize;
    int markerIdxTarget = int(MarkerColor.x + 0.5);

    vec4 center = texture(OutlineSampler, texCoord);
    if (center.a > 0.5) {
        int pC = int(round(center.r * 31.0));
        int idxC = pC >= 16 ? pC - 16 : pC;
        if (idxC != markerIdxTarget) {
            // Crisp vanilla-style outline: edge where a 4-neighbor is empty
            // or belongs to a different silhouette identity.
            float edge = 0.0;
            for (int i = 0; i < 4; i++) {
                vec2 off = i == 0 ? vec2( 1.0, 0.0) : i == 1 ? vec2(-1.0, 0.0)
                         : i == 2 ? vec2( 0.0, 1.0) : vec2( 0.0, -1.0);
                vec4 n = texture(OutlineSampler, texCoord + off * oneTexel);
                if (n.a < 0.5) {
                    edge = 1.0;
                } else {
                    int pN = int(round(n.r * 31.0));
                    int idxN = pN >= 16 ? pN - 16 : pN;
                    if (idxN != idxC && idxN != markerIdxTarget) {
                        edge = 1.0;
                    }
                }
            }
            fragColor = vec4(TEAM_COLORS[clamp(idxC, 0, 15)], edge);
            return;
        }
    }

    float wSum = 0.0;
    float wMarker = 0.0;
    float wEye = 0.0;
    float bestZ = 2.0;
    for (int dy = -3; dy <= 3; dy++) {
        for (int dx = -3; dx <= 3; dx++) {
            float w = (4.0 - abs(float(dx))) * (4.0 - abs(float(dy)));
            wSum += w;
            vec4 s = texture(OutlineSampler, texCoord + vec2(float(dx), float(dy)) * oneTexel);
            if (s.a > 0.5) {
                int p = int(round(s.r * 31.0));
                bool sEye = p >= 16;
                int sIdx = sEye ? p - 16 : p;
                if (sIdx == markerIdxTarget) {
                    wMarker += w;
                    float z = s.g + s.b / 255.0;
                    if (z < bestZ) {
                        bestZ = z;
                    }
                }
            }
        }
    }

    float coverage = wMarker / wSum;
    float edgeFade = smoothstep(0.06, 0.22, coverage);
    if (edgeFade <= 0.0) {
        fragColor = vec4(0.0);
        return;
    }


    vec4 dfEarly = texture(DistSampler, texCoord);
    float distField = clamp((dfEarly.r / max(dfEarly.g, 0.02)) * 32.0, 0.3, 48.0);

    float tol = GlintParams.w + 0.02 * distField;
    float mainZ = texture(MainDepthSampler, texCoord).r;
    if (linearize(bestZ) > linearize(mainZ) + tol) {
        fragColor = vec4(0.0);
        return;
    }


    float frontLimit = linearize(bestZ) + 0.35;
    for (int dy = -3; dy <= 3; dy++) {
        for (int dx = -3; dx <= 3; dx++) {
            float w = (4.0 - abs(float(dx))) * (4.0 - abs(float(dy)));
            vec4 s = texture(OutlineSampler, texCoord + vec2(float(dx), float(dy)) * oneTexel);
            if (s.a > 0.5) {
                int p = int(round(s.r * 31.0));
                if (p >= 16 && p - 16 == markerIdxTarget) {
                    float z = s.g + s.b / 255.0;
                    if (linearize(z) <= frontLimit) {
                        wEye += w;
                    }
                }
            }
        }
    }
    float eyeA = smoothstep(0.08, 0.25, wEye / wSum);

    vec2 p = (texCoord - 0.5) * vec2(OutSize.x / OutSize.y, 1.0) * distField / max(GlintParams.x, 0.05);
    float streak = shimmer(p);

    vec3 col = mix(BaseColor.rgb, GlintColor.rgb, streak);
    float alpha = mix(BaseColor.a, GlintColor.a, streak) * GlintAlpha;

    col = mix(col, vec3(1.0), eyeA);
    alpha = max(alpha, eyeA);

    fragColor = vec4(col, alpha * edgeFade);
}
