#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform DirConfig {
    vec4 BlurDir;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 stepUV = (BlurDir.xy * 3.0) / InSize;
    float sumD = 0.0;
    float sumM = 0.0;
    float sumW = 0.0;
    for (int i = -5; i <= 5; i++) {
        float w = 6.0 - abs(float(i));
        vec4 s = texture(InSampler, texCoord + stepUV * float(i));
        sumD += s.r * w;
        sumM += s.g * w;
        sumW += w;
    }
    fragColor = vec4(sumD / sumW, sumM / sumW, 0.0, 1.0);
}
