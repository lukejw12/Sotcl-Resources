#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

// Stable Player Display (bradleyq / erkko68, CC0), ported to 1.21.11 for PlanePhysics ragdolls.
// A player head drawn 1024*n blocks below its item display is redrawn as limb n of the skin
// (1 right arm, 2 left arm, 3 torso, 4 right leg, 5 left leg) and moved back into place.
#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define MAYBE_PLAYERDISP 1
#endif

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
#ifdef MAYBE_PLAYERDISP
in vec2 texCoord1;
in float part;

#define FADERANGE 12.0
#define FADEBIAS 8.0
#define MINALPHA 0.25

const mat4 bayer4 = mat4( 0.0 / 16.0,  8.0 / 16.0,  2.0 / 16.0, 10.0 / 16.0,
                         12.0 / 16.0,  4.0 / 16.0, 14.0 / 16.0,  6.0 / 16.0,
                          3.0 / 16.0, 11.0 / 16.0,  1.0 / 16.0,  9.0 / 16.0,
                         15.0 / 16.0,  7.0 / 16.0, 13.0 / 16.0,  5.0 / 16.0);
                         
#endif

out vec4 fragColor;

// ============================================================ Hyper Emissive ==
// Separate from the emissive trims (alpha 254). On atlas-sized textures:
//   alpha 252 = hyper core : full-bright, over-bright toward white-hot, cuts through biome fog
//   alpha 251 = hyper halo : partly bright, softer - paint it around a core so the light seems to spill
// Core shaders can't blur across the screen (that needs a post pass), so the "bloom" is the
// over-bright core + baked halo + glowing harder the thicker the fog is around it.
const float HYPER_GAIN       = 1.45;  // core: how much brighter than the texture
const float HYPER_WHITE      = 0.30;  // core: how far bright texels push toward white-hot
const float HALO_STRENGTH    = 0.55;  // halo: 0 = lit like normal, 1 = full-bright
const float HALO_GAIN        = 1.15;  // halo: extra brightness
const float HYPER_FOG_REACH  = 4.0;   // core stays visible this many times deeper into biome fog
const float HALO_FOG_REACH   = 2.5;   // halo reach
const float HYPER_FOG_GLOW   = 0.45;  // extra glow as the surrounding fog thickens (light in haze)
// 0 = normal | 1 = paint core texels green and halo texels blue (checks the markers survive in-game)
const int   HYPER_DEBUG      = 0;

int hyperLevel(vec4 texel, vec2 texSize) {
    if (texSize.x < 256.0) return 0;
    if (texel.a > 251.5 / 255.0 && texel.a < 252.5 / 255.0) return 2;
    if (texel.a > 250.5 / 255.0 && texel.a < 251.5 / 255.0) return 1;
    return 0;
}

float hyperFogLinear(float d, float start, float end) {
    return clamp((d - start) / max(end - start, 0.0001), 0.0, 1.0);
}

vec3 hyperBoost(vec3 rgb, int level) {
    if (level == 2) {
        rgb = min(rgb * HYPER_GAIN, vec3(1.0));
        float l = dot(rgb, vec3(0.299, 0.587, 0.114));
        return mix(rgb, vec3(1.0), HYPER_WHITE * l);
    }
    return min(rgb * HALO_GAIN, vec3(1.0));
}

vec4 hyperFog(vec4 color, int level, float sphDist, float cylDist, vec4 fogColor) {
    float reach = level == 2 ? HYPER_FOG_REACH : HALO_FOG_REACH;
    float envNormal = hyperFogLinear(sphDist, FogEnvironmentalStart, FogEnvironmentalEnd);
    float envHyper  = hyperFogLinear(sphDist, FogEnvironmentalStart, FogEnvironmentalStart + (FogEnvironmentalEnd - FogEnvironmentalStart) * reach);
    float rdFog     = hyperFogLinear(cylDist, FogRenderDistanceStart, FogRenderDistanceEnd);
    color.rgb = min(color.rgb * (1.0 + HYPER_FOG_GLOW * envNormal * (level == 2 ? 1.0 : 0.5)), vec3(1.0));
    float f = max(envHyper, rdFog) * fogColor.a;
    return vec4(mix(color.rgb, fogColor.rgb, f), color.a);
}

vec4 hyperDebug(vec4 c, int level) {
    if (HYPER_DEBUG == 1 && level > 0) return level == 2 ? vec4(0.0, 1.0, 0.0, 1.0) : vec4(0.0, 0.3, 1.0, 1.0);
    return c;
}
// ==============================================================================


void main() {
    vec4 color = texture(Sampler0, texCoord0);
	vec2 texSize = textureSize(Sampler0, 0);
	bool emissiveTrim = (texSize.x >= 256 && color.a > 253.2/255.0 && color.a < 254.8/255.0);
	// markers are read from the full-resolution texel, so distant mipmaps can't blur them away
	vec4 hyperTexel = textureLod(Sampler0, texCoord0, 0.0);
	int hyper = hyperLevel(hyperTexel, texSize);
	if (hyper > 0) color = vec4(hyperTexel.rgb, 1.0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif
#ifdef PER_FACE_LIGHTING
    color *= (gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack) * ColorModulator;
#else
    color *= vertexColor * ColorModulator;
#endif
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    if (emissiveTrim || hyper == 2) {
	} else if (hyper == 1) {
		color *= mix(lightMapColor, vec4(1.0), HALO_STRENGTH);
	} else {
		color *= lightMapColor;
	}
#endif
    if (hyper > 0) {
        color.rgb = hyperBoost(color.rgb, hyper);
        fragColor = hyperDebug(hyperFog(color, hyper, sphericalVertexDistance, cylindricalVertexDistance, FogColor), hyper);
    } else {
        fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
    }
#ifdef MAYBE_PLAYERDISP
    if (part > 1.0 - 10e-6 && fragColor.a < 1.0) {
        fragColor.a = max(fragColor.a, MINALPHA);

        vec3 underCol = texture(Sampler0, texCoord1).rgb;
        vec3 trueMix = mix(underCol, fragColor.rgb, fragColor.a);
        float fade = mix(fragColor.a, 1.0, clamp((cylindricalVertexDistance - FADEBIAS) / (FADERANGE - FADEBIAS), 0.0, 1.0));

        fragColor = vec4((trueMix - (1 - fade) * underCol) / fade,  fade);
        if (fragColor.a < bayer4[int(gl_FragCoord.x) % 4][int(gl_FragCoord.y) % 4] + (0.5 / 16.0)) {
            discard;
        }
        else {
            fragColor.a = 1.0;
        }
    }
#endif
}
