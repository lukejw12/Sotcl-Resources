#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sotcl_nv.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

// PlanePhysics ragdolls: skinned limbs from player heads (idea: Stable Player Display, CC0).
// A player head drawn 1024*n blocks below its item display is redrawn as limb n of the skin
// (1 right arm, 2 left arm, 3 torso, 4 right leg, 5 left leg) and moved back into place.
// Faces are found per pixel from the skin UV, so vertex order (vanilla, Sodium, ...) doesn't matter.
#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define PLANEPHYS_RAGDOLL 1
#endif

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

#ifdef PLANEPHYS_RAGDOLL
uniform sampler2D Sampler0;
#endif
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
#ifdef PLANEPHYS_RAGDOLL
out float ragdollPart;
#define RAGDOLL_SPACING 1024.0
#define RAGDOLL_MAXRANGE 512.0
#endif
out float nvFactor;

void main() {
#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif
#ifndef EMISSIVE
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
#endif
    overlayColor = texelFetch(Sampler1, UV1, 0);

    nvFactor = sotcl_nv_factor(Sampler2);

#ifdef PLANEPHYS_RAGDOLL
    ragdollPart = 0.0;
    {
        ivec2 skinSize = textureSize(Sampler0, 0);
        // world view (not the GUI) and a square skin texture: 64x64 or an HD multiple of it.
        // No fog test: mods that turn fog off (Sodium Extra, Distant Horizons, ...) would fail it,
        // and nothing but a ragdoll limb ever sits 1024+ blocks below its display anyway.
        if (abs(ProjMat[2][3]) > 1e-5 && skinSize.x == skinSize.y && skinSize.x >= 64 && (skinSize.x % 64) == 0) {
            int limb = -int((Position.y - RAGDOLL_MAXRANGE) / RAGDOLL_SPACING);
            if (limb >= 1 && limb <= 5) {
                ragdollPart = float(limb);
                vec3 wpos = Position + vec3(0.0, RAGDOLL_SPACING * float(limb), 0.0);
                gl_Position = ProjMat * ModelViewMat * vec4(wpos, 1.0);
                sphericalVertexDistance = fog_spherical_distance(wpos);
                cylindricalVertexDistance = fog_cylindrical_distance(wpos);
                texCoord0 = UV0;
                return;
            }
        }
    }
#endif

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    texCoord0 = UV0;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
