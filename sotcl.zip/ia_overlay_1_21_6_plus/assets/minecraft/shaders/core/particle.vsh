#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;

// --- Bad Luck (unluck) particle recolor ---------------------------------
// The entity_effect particle is a white swirl tinted by the effect's color,
// delivered here through the raw `Color` vertex attribute (0..1, before the
// lightmap is applied). We match the vanilla unluck tint and swap it out.
//
//   unluck source : #C0A44D = (192,164, 77)/255 = (0.75294, 0.64314, 0.30196)
//   target        : #200020 = ( 32,  0, 32)/255 = (0.12549, 0.00000, 0.12549)
//
// The match is keyed to that specific tint with a small tolerance, so no other
// effect (nearest is Haste at ~0.15 away) is touched.
const vec3 UNLUCK_SRC = vec3(0.75294, 0.64314, 0.30196);
const vec3 UNLUCK_DST = vec3(0.12549, 0.00000, 0.12549);
const float UNLUCK_TOLERANCE = 0.05;

void main() {
    vec4 col = Color;

    if (distance(col.rgb, UNLUCK_SRC) < UNLUCK_TOLERANCE) {
        col.rgb = UNLUCK_DST;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
}
