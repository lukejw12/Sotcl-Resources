#version 330

#moj_import <minecraft:fog.glsl>

// Vanilla panorama.fsh draws the End sky cubemap with no fog at all, which is
// why biome fog never affects it. This blends the sky toward the fog colour
// when the camera is in a biome with very tight fog (endercon:end_depths).
//
// It cannot read the biome directly - no core shader can - so it keys off
// FogEnvironmentalEnd, which is the biome's fog_end_distance:
//     endercon:end_depths   30
//     minecraft:the_end    128
//     endercon:end_skies   320
//     endercon:end_hallows 512
//     dimension default   1024
// Only the depths sit anywhere near the threshold below.

uniform samplerCube Sampler0;

in vec3 texCoord0;

out vec4 fragColor;

// ---------------------------------------------------------------- tuning --
const float SKY_FOG_FULL = 45.0;   // fog end at/below this -> sky fully hidden
const float SKY_FOG_NONE = 100.0;  // fog end at/above this -> sky untouched
const float SKY_FOG_MAX  = 1.0;    // 1.0 = opaque, 0.85 leaves a faint hint

// 0 = off (normal)
// 1 = tint the sky red always      -> is this file being loaded at all?
// 2 = show the fog uniforms        -> is the Fog UBO actually bound here?
//     red channel   = FogColor.a  (should be 1 in-world)
//     green channel = FogEnvironmentalEnd / 128
const int DEBUG_MODE = 0;
// ---------------------------------------------------------------------------

void main() {
    vec4 color = texture(Sampler0, texCoord0);

    // FogColor.a is 0 when there is no active world fog, which keeps the main
    // menu panorama and menu backgrounds untouched. The range checks reject
    // nonsense in case this pipeline does not bind the Fog block.
    float valid = step(1.0, FogEnvironmentalEnd)
                * step(FogEnvironmentalEnd, 4096.0)
                * clamp(FogColor.a, 0.0, 1.0);

    float amount = 1.0 - smoothstep(SKY_FOG_FULL, SKY_FOG_NONE, FogEnvironmentalEnd);
    amount = clamp(amount * valid * SKY_FOG_MAX, 0.0, 1.0);

    vec3 result = mix(color.rgb, FogColor.rgb, amount);

    if (DEBUG_MODE == 1) {
        result = vec3(1.0, 0.0, 0.0);
    } else if (DEBUG_MODE == 2) {
        result = vec3(FogColor.a, FogEnvironmentalEnd / 128.0, 0.0);
    }

    fragColor = vec4(result, color.a);
}
