#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:sotcl_nv.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;
layout(location = 3) in ivec2 UV2;

uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec2 texCoord0;
layout(location = 3) out vec4 vertexColor;
layout(location = 8) out float nvFactor;

const vec3 UNLUCK_SRC = vec3(0.75294, 0.64314, 0.30196);
const vec3 UNLUCK_DST = vec3(0.12549, 0.00000, 0.12549);
const float UNLUCK_TOLERANCE = 0.05;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
    vec4 col = Color;
    if (distance(col.rgb, UNLUCK_SRC) < UNLUCK_TOLERANCE) {
        col.rgb = UNLUCK_DST;
    }
    vertexColor = col * sample_lightmap(Sampler2, UV2);
    nvFactor = sotcl_nv_factor(Sampler2);
}
