#ifndef SOTCL_NV_GLSL
#define SOTCL_NV_GLSL

const float SOTCL_NV_FOG_REACH = 2.5;
const float SOTCL_NV_FOG_START = 1.6;

float sotcl_nv_factor(sampler2D lightMap) {
    vec3 dark = texture(lightMap, vec2(0.5 / 16.0, 0.5 / 16.0)).rgb;
    float l = max(max(dark.r, dark.g), dark.b);
    return smoothstep(0.45, 0.7, l);
}

void sotcl_nv_fog_bounds(float nv, inout float fogStart, inout float fogEnd) {
    float span = fogEnd - fogStart;
    fogStart = fogStart * mix(1.0, SOTCL_NV_FOG_START, nv);
    fogEnd = fogStart + span * mix(1.0, SOTCL_NV_FOG_REACH, nv);
}

#endif
