#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_6d410299(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_764effaa() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_8c87a548(inout vec4 vertex) {
    f_6d410299(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_764effaa();
    }
        finalize();
}



void f_25a24efe() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_d0b09771() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_e36a997f(inout vec4 vertex) {
    f_6d410299(vertex);
    f_25a24efe();
    finalize();
}

void f_cd221fa2(inout vec4 vertex) {
    f_6d410299(vertex);
    f_764effaa();
    f_d0b09771();
    finalize();
}

void f_1c2d528c(inout vec4 vertex) {
    f_6d410299(vertex);
    f_d0b09771();
    f_25a24efe();
    finalize();
}

void f_68aca483(inout vec4 vertex) {
    f_764effaa();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_6d410299(vertex);
    finalize();
}

void f_ed2561cf(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_25a24efe();
    f_6d410299(vertex);
    finalize();
}

void f_e2cd568a(inout vec4 vertex, float speed) {
    f_6d410299(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_1674bd65(inout vec4 vertex) {
    f_6d410299(vertex);
    f_764effaa();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_8c87a548(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_764effaa();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_6d410299(vertex);
            f_764effaa();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_cd221fa2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_cd221fa2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_68aca483(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_68aca483(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_e2cd568a(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_1674bd65(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_e36a997f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_cd221fa2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_1c2d528c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_68aca483(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_ed2561cf(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_e2cd568a(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_e36a997f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_cd221fa2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_1c2d528c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_68aca483(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_ed2561cf(vertex);
        return;
    }
    

    
    f_6d410299(vertex);
    f_764effaa();
    finalize();
}