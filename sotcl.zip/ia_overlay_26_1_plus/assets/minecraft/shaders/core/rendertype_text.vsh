#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_2f73cd8d(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_e9b0aa7d() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_34cabb5d(inout vec4 vertex) {
    f_2f73cd8d(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_e9b0aa7d();
    }
        finalize();
}



void f_de36c6d7() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_cea4cf10() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_52829f8c(inout vec4 vertex) {
    f_2f73cd8d(vertex);
    f_de36c6d7();
    finalize();
}

void f_eae0f8e5(inout vec4 vertex) {
    f_2f73cd8d(vertex);
    f_e9b0aa7d();
    f_cea4cf10();
    finalize();
}

void f_ddfb9fff(inout vec4 vertex) {
    f_2f73cd8d(vertex);
    f_cea4cf10();
    f_de36c6d7();
    finalize();
}

void f_4d71c30f(inout vec4 vertex) {
    f_e9b0aa7d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_2f73cd8d(vertex);
    finalize();
}

void f_2873d0ec(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_de36c6d7();
    f_2f73cd8d(vertex);
    finalize();
}

void f_9e5f7c63(inout vec4 vertex, float speed) {
    f_2f73cd8d(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_b90e375d(inout vec4 vertex) {
    f_2f73cd8d(vertex);
    f_e9b0aa7d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_34cabb5d(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_e9b0aa7d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_2f73cd8d(vertex);
            f_e9b0aa7d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_eae0f8e5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_eae0f8e5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_4d71c30f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_4d71c30f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_9e5f7c63(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_b90e375d(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_52829f8c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_eae0f8e5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_ddfb9fff(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_4d71c30f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_2873d0ec(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_9e5f7c63(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_52829f8c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_eae0f8e5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_ddfb9fff(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_4d71c30f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_2873d0ec(vertex);
        return;
    }
    

    
    f_2f73cd8d(vertex);
    f_e9b0aa7d();
    finalize();
}