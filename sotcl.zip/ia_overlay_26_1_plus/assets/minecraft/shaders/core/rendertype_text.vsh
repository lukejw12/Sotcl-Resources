#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_0b9dbc4b(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_230738f2() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_4cd3cd3f(inout vec4 vertex) {
    f_0b9dbc4b(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_230738f2();
    }
        finalize();
}



void f_ed28d855() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_8cef3bf7() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_4e1fd420(inout vec4 vertex) {
    f_0b9dbc4b(vertex);
    f_ed28d855();
    finalize();
}

void f_b98ba836(inout vec4 vertex) {
    f_0b9dbc4b(vertex);
    f_230738f2();
    f_8cef3bf7();
    finalize();
}

void f_a036a124(inout vec4 vertex) {
    f_0b9dbc4b(vertex);
    f_8cef3bf7();
    f_ed28d855();
    finalize();
}

void f_3067ed1d(inout vec4 vertex) {
    f_230738f2();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0b9dbc4b(vertex);
    finalize();
}

void f_843b7938(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_ed28d855();
    f_0b9dbc4b(vertex);
    finalize();
}

void f_c89067e9(inout vec4 vertex, float speed) {
    f_0b9dbc4b(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_a9c24325(inout vec4 vertex) {
    f_0b9dbc4b(vertex);
    f_230738f2();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_4cd3cd3f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_230738f2();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_0b9dbc4b(vertex);
            f_230738f2();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b98ba836(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b98ba836(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_3067ed1d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_3067ed1d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c89067e9(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_a9c24325(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_4e1fd420(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b98ba836(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_a036a124(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_3067ed1d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_843b7938(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c89067e9(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_4e1fd420(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b98ba836(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_a036a124(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_3067ed1d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_843b7938(vertex);
        return;
    }
    

    
    f_0b9dbc4b(vertex);
    f_230738f2();
    finalize();
}