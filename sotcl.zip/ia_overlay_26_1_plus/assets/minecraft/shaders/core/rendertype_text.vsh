#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_1a807aac(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_773b9bd3() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_89e69b97(inout vec4 vertex) {
    f_1a807aac(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_773b9bd3();
    }
        finalize();
}



void f_4ef83efd() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_f0f2b680() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_38c89fdb(inout vec4 vertex) {
    f_1a807aac(vertex);
    f_4ef83efd();
    finalize();
}

void f_27f48c05(inout vec4 vertex) {
    f_1a807aac(vertex);
    f_773b9bd3();
    f_f0f2b680();
    finalize();
}

void f_b54bcd85(inout vec4 vertex) {
    f_1a807aac(vertex);
    f_f0f2b680();
    f_4ef83efd();
    finalize();
}

void f_bac0663f(inout vec4 vertex) {
    f_773b9bd3();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1a807aac(vertex);
    finalize();
}

void f_80927bcb(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_4ef83efd();
    f_1a807aac(vertex);
    finalize();
}

void f_a7b7894c(inout vec4 vertex, float speed) {
    f_1a807aac(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_15fe251f(inout vec4 vertex) {
    f_1a807aac(vertex);
    f_773b9bd3();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_89e69b97(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_773b9bd3();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_1a807aac(vertex);
            f_773b9bd3();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_27f48c05(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_27f48c05(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_bac0663f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_bac0663f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_a7b7894c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_15fe251f(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_38c89fdb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_27f48c05(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_b54bcd85(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_bac0663f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_80927bcb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_a7b7894c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_38c89fdb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_27f48c05(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_b54bcd85(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_bac0663f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_80927bcb(vertex);
        return;
    }
    

    
    f_1a807aac(vertex);
    f_773b9bd3();
    finalize();
}