#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_4ba2d63e(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_73843421() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_d17d010b(inout vec4 vertex) {
    f_4ba2d63e(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_73843421();
    }
        finalize();
}



void f_098ea5e1() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_085f198b() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_dcd9de58(inout vec4 vertex) {
    f_4ba2d63e(vertex);
    f_098ea5e1();
    finalize();
}

void f_c5e52965(inout vec4 vertex) {
    f_4ba2d63e(vertex);
    f_73843421();
    f_085f198b();
    finalize();
}

void f_2519d9a8(inout vec4 vertex) {
    f_4ba2d63e(vertex);
    f_085f198b();
    f_098ea5e1();
    finalize();
}

void f_475cf166(inout vec4 vertex) {
    f_73843421();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_4ba2d63e(vertex);
    finalize();
}

void f_98a1590e(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_098ea5e1();
    f_4ba2d63e(vertex);
    finalize();
}

void f_febdf8b5(inout vec4 vertex, float speed) {
    f_4ba2d63e(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_eabefaba(inout vec4 vertex) {
    f_4ba2d63e(vertex);
    f_73843421();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_d17d010b(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_73843421();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_4ba2d63e(vertex);
            f_73843421();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_c5e52965(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_c5e52965(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_475cf166(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_475cf166(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_febdf8b5(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_eabefaba(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_dcd9de58(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_c5e52965(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_2519d9a8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_475cf166(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_98a1590e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_febdf8b5(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_dcd9de58(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_c5e52965(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_2519d9a8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_475cf166(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_98a1590e(vertex);
        return;
    }
    

    
    f_4ba2d63e(vertex);
    f_73843421();
    finalize();
}