#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_7d714016(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_a297358c() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_0de62d34(inout vec4 vertex) {
    f_7d714016(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_a297358c();
    }
        finalize();
}



void f_59b7b70f() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_afeeb9d7() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_18250dba(inout vec4 vertex) {
    f_7d714016(vertex);
    f_59b7b70f();
    finalize();
}

void f_e9a83c58(inout vec4 vertex) {
    f_7d714016(vertex);
    f_a297358c();
    f_afeeb9d7();
    finalize();
}

void f_3bae018d(inout vec4 vertex) {
    f_7d714016(vertex);
    f_afeeb9d7();
    f_59b7b70f();
    finalize();
}

void f_1e90e7d7(inout vec4 vertex) {
    f_a297358c();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7d714016(vertex);
    finalize();
}

void f_9d27c24e(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_59b7b70f();
    f_7d714016(vertex);
    finalize();
}

void f_4239423b(inout vec4 vertex, float speed) {
    f_7d714016(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_287f5caf(inout vec4 vertex) {
    f_7d714016(vertex);
    f_a297358c();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_0de62d34(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_a297358c();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_7d714016(vertex);
            f_a297358c();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_e9a83c58(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_e9a83c58(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_1e90e7d7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_1e90e7d7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_4239423b(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_287f5caf(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_18250dba(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_e9a83c58(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_3bae018d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_1e90e7d7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_9d27c24e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_4239423b(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_18250dba(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_e9a83c58(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_3bae018d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_1e90e7d7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_9d27c24e(vertex);
        return;
    }
    

    
    f_7d714016(vertex);
    f_a297358c();
    finalize();
}