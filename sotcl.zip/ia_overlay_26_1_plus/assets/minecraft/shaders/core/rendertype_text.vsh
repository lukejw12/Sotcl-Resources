#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_5688086f(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ff842c2e() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_f35e4286(inout vec4 vertex) {
    f_5688086f(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ff842c2e();
    }
        finalize();
}



void f_b49cfafe() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_a10c3387() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_ae8845c6(inout vec4 vertex) {
    f_5688086f(vertex);
    f_b49cfafe();
    finalize();
}

void f_f178def5(inout vec4 vertex) {
    f_5688086f(vertex);
    f_ff842c2e();
    f_a10c3387();
    finalize();
}

void f_30a2990d(inout vec4 vertex) {
    f_5688086f(vertex);
    f_a10c3387();
    f_b49cfafe();
    finalize();
}

void f_547d5030(inout vec4 vertex) {
    f_ff842c2e();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_5688086f(vertex);
    finalize();
}

void f_ea225f8b(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_b49cfafe();
    f_5688086f(vertex);
    finalize();
}

void f_c1564b28(inout vec4 vertex, float speed) {
    f_5688086f(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_5ee4a0e5(inout vec4 vertex) {
    f_5688086f(vertex);
    f_ff842c2e();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_f35e4286(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ff842c2e();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_5688086f(vertex);
            f_ff842c2e();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_f178def5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_f178def5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_547d5030(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_547d5030(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c1564b28(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_5ee4a0e5(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_ae8845c6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_f178def5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_30a2990d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_547d5030(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_ea225f8b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c1564b28(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_ae8845c6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_f178def5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_30a2990d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_547d5030(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_ea225f8b(vertex);
        return;
    }
    

    
    f_5688086f(vertex);
    f_ff842c2e();
    finalize();
}