#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_2b591667(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_a8a1bcc7() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_bba48760(inout vec4 vertex) {
    f_2b591667(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_a8a1bcc7();
    }
        finalize();
}



void f_c159e268() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_6a4b5f31() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_5c33819e(inout vec4 vertex) {
    f_2b591667(vertex);
    f_c159e268();
    finalize();
}

void f_40b64461(inout vec4 vertex) {
    f_2b591667(vertex);
    f_a8a1bcc7();
    f_6a4b5f31();
    finalize();
}

void f_40abd635(inout vec4 vertex) {
    f_2b591667(vertex);
    f_6a4b5f31();
    f_c159e268();
    finalize();
}

void f_a2081652(inout vec4 vertex) {
    f_a8a1bcc7();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_2b591667(vertex);
    finalize();
}

void f_c8eb2355(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_c159e268();
    f_2b591667(vertex);
    finalize();
}

void f_7bed1476(inout vec4 vertex, float speed) {
    f_2b591667(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_45a54652(inout vec4 vertex) {
    f_2b591667(vertex);
    f_a8a1bcc7();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_bba48760(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_a8a1bcc7();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_2b591667(vertex);
            f_a8a1bcc7();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_40b64461(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_40b64461(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_a2081652(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_a2081652(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_7bed1476(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_45a54652(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_5c33819e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_40b64461(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_40abd635(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_a2081652(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c8eb2355(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_7bed1476(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_5c33819e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_40b64461(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_40abd635(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_a2081652(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c8eb2355(vertex);
        return;
    }
    

    
    f_2b591667(vertex);
    f_a8a1bcc7();
    finalize();
}