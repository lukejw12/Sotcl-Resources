#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_0626add7(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d296ab38() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_ef770c13(inout vec4 vertex) {
    f_0626add7(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d296ab38();
    }
        finalize();
}



void f_61ff0bcb() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_245a3599() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_7705a88c(inout vec4 vertex) {
    f_0626add7(vertex);
    f_61ff0bcb();
    finalize();
}

void f_4cd7a85c(inout vec4 vertex) {
    f_0626add7(vertex);
    f_d296ab38();
    f_245a3599();
    finalize();
}

void f_507aba7d(inout vec4 vertex) {
    f_0626add7(vertex);
    f_245a3599();
    f_61ff0bcb();
    finalize();
}

void f_ec8da609(inout vec4 vertex) {
    f_d296ab38();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0626add7(vertex);
    finalize();
}

void f_0bec7693(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_61ff0bcb();
    f_0626add7(vertex);
    finalize();
}

void f_5f5e580c(inout vec4 vertex, float speed) {
    f_0626add7(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_22f09637(inout vec4 vertex) {
    f_0626add7(vertex);
    f_d296ab38();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_ef770c13(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d296ab38();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_0626add7(vertex);
            f_d296ab38();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_4cd7a85c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_4cd7a85c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_ec8da609(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_ec8da609(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_5f5e580c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_22f09637(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_7705a88c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_4cd7a85c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_507aba7d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_ec8da609(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_0bec7693(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_5f5e580c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_7705a88c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_4cd7a85c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_507aba7d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_ec8da609(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_0bec7693(vertex);
        return;
    }
    

    
    f_0626add7(vertex);
    f_d296ab38();
    finalize();
}