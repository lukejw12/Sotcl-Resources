#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_e9e49369(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_783673bf() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_3fe2f883(inout vec4 vertex) {
    f_e9e49369(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_783673bf();
    }
        finalize();
}



void f_34feeaaf() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_08a1dbca() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_714ab83f(inout vec4 vertex) {
    f_e9e49369(vertex);
    f_34feeaaf();
    finalize();
}

void f_83683b3a(inout vec4 vertex) {
    f_e9e49369(vertex);
    f_783673bf();
    f_08a1dbca();
    finalize();
}

void f_66e6ed21(inout vec4 vertex) {
    f_e9e49369(vertex);
    f_08a1dbca();
    f_34feeaaf();
    finalize();
}

void f_c5846de5(inout vec4 vertex) {
    f_783673bf();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_e9e49369(vertex);
    finalize();
}

void f_4d85de53(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_34feeaaf();
    f_e9e49369(vertex);
    finalize();
}

void f_c4b4f222(inout vec4 vertex, float speed) {
    f_e9e49369(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_390a457d(inout vec4 vertex) {
    f_e9e49369(vertex);
    f_783673bf();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_3fe2f883(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_783673bf();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_e9e49369(vertex);
            f_783673bf();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_83683b3a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_83683b3a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_c5846de5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_c5846de5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c4b4f222(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_390a457d(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_714ab83f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_83683b3a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_66e6ed21(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_c5846de5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_4d85de53(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c4b4f222(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_714ab83f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_83683b3a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_66e6ed21(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_c5846de5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_4d85de53(vertex);
        return;
    }
    

    
    f_e9e49369(vertex);
    f_783673bf();
    finalize();
}