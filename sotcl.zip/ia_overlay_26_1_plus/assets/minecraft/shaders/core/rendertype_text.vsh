#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_d4fc0ff1(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_44515f85() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_28cc3bd1(inout vec4 vertex) {
    f_d4fc0ff1(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_44515f85();
    }
        finalize();
}



void f_ab282498() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_1938fab1() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_8bd2f7fc(inout vec4 vertex) {
    f_d4fc0ff1(vertex);
    f_ab282498();
    finalize();
}

void f_8c56f1a1(inout vec4 vertex) {
    f_d4fc0ff1(vertex);
    f_44515f85();
    f_1938fab1();
    finalize();
}

void f_f752f41c(inout vec4 vertex) {
    f_d4fc0ff1(vertex);
    f_1938fab1();
    f_ab282498();
    finalize();
}

void f_b2471e50(inout vec4 vertex) {
    f_44515f85();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_d4fc0ff1(vertex);
    finalize();
}

void f_c1936674(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_ab282498();
    f_d4fc0ff1(vertex);
    finalize();
}

void f_2980d8e4(inout vec4 vertex, float speed) {
    f_d4fc0ff1(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_b4cc8d09(inout vec4 vertex) {
    f_d4fc0ff1(vertex);
    f_44515f85();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_28cc3bd1(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_44515f85();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_d4fc0ff1(vertex);
            f_44515f85();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_8c56f1a1(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_8c56f1a1(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_b2471e50(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_b2471e50(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_2980d8e4(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_b4cc8d09(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_8bd2f7fc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_8c56f1a1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_f752f41c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_b2471e50(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c1936674(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_2980d8e4(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_8bd2f7fc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_8c56f1a1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_f752f41c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_b2471e50(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c1936674(vertex);
        return;
    }
    

    
    f_d4fc0ff1(vertex);
    f_44515f85();
    finalize();
}